package com.baby;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;





@SpringBootApplication
public class BabyAmazonApplication {

	public static void main(String[] args) {
		SpringApplication.run(BabyAmazonApplication.class, args);
	}
	
}
