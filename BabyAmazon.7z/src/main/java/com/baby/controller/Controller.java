package com.baby.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.baby.models.Products;
import com.baby.models.User;
import com.baby.services.ProductsService;
import com.baby.security.JwtService;

@CrossOrigin(origins ="http://localhost:4200")
@RestController
public class Controller {
	
	@Autowired
	ProductsService productsService;
	
	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	JwtService jwtService;
	
	
	//login user  or admin
	
	@PostMapping("/login")	
	public ResponseEntity<String> login (@RequestBody User user) throws Exception {
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken
				(user.getUsername(), user.getPassword()));
		if( authentication.isAuthenticated()) {
			String token = jwtService.generateToken(user.getUsername());
		return new ResponseEntity<String>(token,HttpStatus.OK);
		}
		else {
			throw new Exception("user invalid");
		}
		
	}
	// get all products 
	@GetMapping("/allProducts")
	public List<Products> getAllProducts() {
		return productsService.getAllProducts();
		
	}
	
	//dummy endpoint for exxperiments
	@GetMapping("/check")
	public ResponseEntity<String> testing () {
		return new ResponseEntity<String>("checked", HttpStatus.OK);
	}
	
	// add to cart 
	@PostMapping("/addToCart/{productID}")
	public ResponseEntity<Products> addToCart(@RequestBody User user, @PathVariable("productID") Long productID) {
		Products product = productsService.addToCart(productID,user );
		return  new ResponseEntity<Products>(product, HttpStatus.OK);
		
	}
	// buy
	@PostMapping("/buyProduct/{productID}")
	public ResponseEntity<Products> buyProduct(@RequestBody User user, @PathVariable("productID") Long productID) {
		Products product = productsService.buyProduct(productID,user );
		return  new ResponseEntity<Products>(product, HttpStatus.OK);
	}
	
	//admin report api
	
}
