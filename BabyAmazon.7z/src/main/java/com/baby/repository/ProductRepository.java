package com.baby.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.baby.models.Products;

@Repository
public interface ProductRepository extends CrudRepository<Products, Long> {
	
	List<Products> findAll();

	Products findByProductId(Long prodid);


}
