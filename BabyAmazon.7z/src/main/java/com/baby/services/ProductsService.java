package com.baby.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baby.models.Products;
import com.baby.models.User;
import com.baby.repository.ProductRepository;
import com.baby.repository.UserRepo;

@Service
public class ProductsService {
	
	@Autowired
	ProductRepository productRepo;
	
	@Autowired
	UserRepo userRepository;
	
	
	 public List<Products> getAllProducts() {
		return productRepo.findAll();	
	}


	public Products addToCart(Long productID, User user) {
		Products prod = productRepo.findByProductId(productID);
		User userInstance = userRepository.findByUsername(user.getUsername());
		prod.setAddedToCartUser(userInstance);
		return productRepo.save(prod);
		
	}
	
	public Products buyProduct(Long productID, User user) {
		Products prod = productRepo.findByProductId(productID);
		User userInstance = userRepository.findByUsername(user.getUsername());
		prod.setBoughtbyUser(userInstance);
		return productRepo.save(prod);
	
	}

}
